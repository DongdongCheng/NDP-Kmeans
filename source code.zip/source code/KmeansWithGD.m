% -------------------------------------------------------------------------
%Aim:
%cluster NDPs with improved kmeans
% -------------------------------------------------------------------------
% Written by Dongdong Cheng
% December 2021

function [cluster_labels] = KmeansWithGD(data,centers,num_clusters,graphdist,rho)
%distΪ���ĵ�֮��Ļ������·���ľ���
%AΪ�ֲ����ĵ�/�ܶȷ�,Ncores*d
%clΪkmeans�ľ�������ÿ���ֲ����ĵ�����ǩ
%
%   Input    : data           : �ֲ����ĵ�/�ܶȷ�,Ncores*d,
%                               D is the number of dimensions
%              centers        : K-by-D matrix, where K is num_clusters, or
%                               'random', random initialization, or
%                               [], empty matrix, orthogonal initialization
%              num_clusters   : Number of clusters
%
%   Output   : cluster_labels : N-by-1 vector of cluster assignment
%
% Parameter setting
%
% tic;
iter = 0;
qold = inf;
threshold = 0.00000001;

%
% Check if with initial centers
%
if strcmp(centers, 'random')
  centers=plus_init(graphdist,num_clusters,rho);
elseif isempty(centers)
 % disp('Orthogonal initialization...');
  centers = orth_init(data, num_clusters);
end

n = size(data, 1);
%����ͼ������㷨����
P=graphdist(centers,:);
% fprintf('��ʼ������Ϊ:')
while iter<=100
  iter = iter + 1;
  % Find the closest cluster for each data point�����Է����ĵ���л���
  [val, ind] = min(P, [], 1); 
%   input('����enter');
%   drawcluster2(data,ind,num_clusters);
  %update centers
  clusters=cell(num_clusters,1);
  for i=1:num_clusters
      clusters{i}=find(ind==i);
      %�����i���ص�ÿ������������ľ���֮��
      mindist=inf;
      for j=1:length(clusters{i})
          dis=sum(graphdist(clusters{i}(j),clusters{i}));
          if mindist>dis
              mindist=dis;
              mind=clusters{i}(j);
          end
      end
      centers(i)=mind;
  end
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %update members
  P=graphdist(centers,:);
  %����Ŀ�꺯��
   % Calculate objective function value
  qnew = sum(sum(sparse(ind, 1:n, 1, size(P, 1), size(P, 2)).*P));
%   mesg = sprintf('Iteration %d:\n\tQold=%g\t\tQnew=%g', iter, full(qold), full(qnew));
%   disp(mesg);

  % Check if objective function value is less than/equal to threshold
  if threshold >= abs((qnew-qold)/qold)
%     mesg = sprintf('\nkmeans converged!');
%     disp(mesg);
    break;
  end
  qold = qnew;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cluster_labels = ind';
ncluster=max(cluster_labels);
end
%-----------------------------------------------------------------------------
function init_centers = random_init(data, num_clusters)
%RANDOM_INIT Initialize centroids choosing num_clusters rows of data at random
%
%   Input : data         : N-by-D data matrix, where N is the number of data,
%                          D is the number of dimensions
%           num_clusters : Number of clusters
%
%   Output: init_centers : K-by-D matrix, where K is num_clusters
rand('twister', sum(100*clock));
init_centers = data(ceil(size(data, 1)*rand(1, num_clusters)), :);
end
%--------------------------------------------------------------------------
function centers = random_init2(data, num_clusters)
%RANDOM_INIT Initialize centroids choosing num_clusters rows of data at random
%
%   Input : data         : N-by-D data matrix, where N is the number of data,
%                          D is the number of dimensions
%           num_clusters : Number of clusters
%
%   Output: centers : the ind of centers,K-by-1 matrix, where K is num_clusters
rand('twister', sum(100*clock));
centers =ceil(size(data, 1)*rand(1, num_clusters));
end
%--------------------------------------------------------------------------
function centers=plus_init(core_dist,num_clusters,rho)
%��ʼ�����ĵ��Ż�������ѡ���������ܶȵĶ�����Ϊ��һ�������ģ�
%Ȼ��ѡ������һ��������Զ�Ķ�����Ϊ�ڶ��������ģ���������ѡ��ֱ��ѡ��K��������
centers=zeros(num_clusters,1);
[maxv,maxid]=max(rho);
centers(1)=maxid;%��һ�������ĵ��±�
num_centers=1;
n=size(core_dist,2);%��ȡ�������
while num_centers<num_clusters
    %�����������е㵽��ѡ��ÿ�������ĵľ���
    dists=zeros(n,num_centers);
    for i=1:num_centers
        dists(:,i)=core_dist(centers(i),:);
    end
    mindist=min(dists,[],2);
    [~,maxid2]=max(mindist);
    num_centers=num_centers+1;
    centers(num_centers)=maxid2;
end

end
function init_centers = orth_init(data, num_clusters)
%ORTH_INIT Initialize orthogonal centers for k-means clustering algorithm.
%
%   Input : data         : N-by-D data matrix, where N is the number of data,
%                          D is the number of dimensions
%           num_clusters : Number of clusters
%
%   Output: init_centers : K-by-D matrix, where K is num_clusters

%
% Find the num_clusters centers which are orthogonal to each other
%
Uniq = unique(data, 'rows'); % Avoid duplicate centers
num = size(Uniq, 1);
first = ceil(rand(1)*num); % Randomly select the first center
init_centers = zeros(num_clusters, size(data, 2)); % Storage for centers
init_centers(1, :) = Uniq(first, :);
Uniq(first, :) = [];
c = zeros(num-1, 1); % Accumalated orthogonal values to existing centers for non-centers
% Find the rest num_clusters-1 centers
for j = 2:num_clusters
  c = c + abs(Uniq*init_centers(j-1, :)');
  [minimum, i] = min(c); % Select the most orthogonal one as next center
  init_centers(j, :) = Uniq(i, :);
  Uniq(i, :) = [];
  c(i) = [];
end

end




