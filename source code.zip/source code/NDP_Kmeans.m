% -------------------------------------------------------------------------
%Aim:
%K-means clustering with natural density peaks for discovering arbitrary-shaped clusters
% -------------------------------------------------------------------------
%Input:
%A: the data set
%num_clusters: the expected number of clusters
%alpha:the proportion of noises [0,0.2]
% -------------------------------------------------------------------------
%output:
%cl2:the cluster label of each point n*1
% Written by Dongdong Cheng
% January 2022
function [cl2] = NDP_Kmeans( A,num_clusters,alpha)
%A:The data set n*d

tic;
[N,dim]=size(A);
fprintf('Searching NDPs......\n');
[index,supk,nb,rho,local_core,cores,cl,cluster_number ] = NDP_Searching(A);
[rho_sorted,~]=sort(rho,'ascend');
if alpha==0
    rho_threshold=0;
else
    rho_threshold=rho_sorted(floor(N*alpha));%0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eliminate low density NDPs
for i=1:cluster_number
    if cores(i)~=0
    if rho(cores(i))<rho_threshold %�ų��ܶȽ�С�ĺ��ĵ�
        mind=inf;
        p=0;
        for j=1:cluster_number
            if i~=j
                x=A(cores(i),:);
                y=A(cores(j),:);
                distance=sqrt(sum((x-y).^2));
%                 distance=pdist2(A(cores(i),:),A(cores(j),:));
            if mind>distance&&rho(cores(j))>rho_threshold
                mind=distance;
                p=j;
            end
            end
        end
        for j=1:N
            if local_core(j)==cores(i)
                local_core(j)=cores(p);
            end
        end
    end
    end
end
cluster_number=0;
cl=zeros(N,1);
for i=1:N
    if local_core(i)==i;
       cluster_number=cluster_number+1;
       cores2(cluster_number)=i;
       cl(i)=cluster_number;
    end
end
disp('The number of NDPs is ');disp(cluster_number);
for i=1:N
    cl(i)=cl(local_core(i));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
fprintf('Computing GD matrix of NDPs......\n');
cdata=cell(1,cluster_number);%����ÿ�����ж�����Щ��
cdataexp=cell(1,cluster_number);%����ÿ�����еĵ㼰ÿ�����е�k����
nc=zeros(1,cluster_number);%��������ĳ�����ĵ�ĵ���
ncexp=zeros(1,cluster_number);
core_dist=zeros(cluster_number,cluster_number);
for i=1:cluster_number
    for j=i+1:cluster_number
        x=A(cores2(i),:);
        y=A(cores2(j),:);
        d=sqrt(sum((x-y).^2));
        core_dist(i,j)=d;
        core_dist(j,i)=d;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
maxd=10*max(max(core_dist));
sd=zeros(cluster_number,1);
for i=1:cluster_number
    nc(i)=0;
    ncexp(i)=0;
    x=A(cores2(i),:);
    for j=1:N
        if cl(j)==i&&rho(j)>rho_threshold
            nc(i)=nc(i)+1;
            y=A(j,:);
            sd(i)=sd(i)+sqrt(sum((x-y).^2));
            ncexp(i)=ncexp(i)+1;
            cdata{1,i}(1,nc(i))=j;
            cdataexp{1,i}(1,ncexp(i))=j;
        end
    end
    for j=1:ncexp(i)
       x=cdata{1,i}(1,j);
       d2=sqrt(sum((A(x,:)-A(cores2(i),:)).^2));
       for k=2:supk+1
           kneighbor=index(x,k);
           if iscontain(cdataexp{1,i}',kneighbor)==0&&rho(kneighbor)>rho_threshold
               ncexp(i)=ncexp(i)+1;
               cdataexp{1,i}(1,ncexp(i))=kneighbor;
           end
       end
    end 
   
end
sharedCount=zeros(cluster_number,cluster_number);
count=0;
for i=1:cluster_number
    for j=i+1:cluster_number
        inset1=intersect(cdataexp{1,i},cdataexp{1,j});
        averho=sum(rho(inset1));
        [~,numinset1]=size(inset1);
        sharedCount(i,j)=numinset1;
        sharedCount(j,i)=numinset1;
        if numinset1==0%&&numinset2==0
            core_dist(i,j)=maxd*(core_dist(i,j)+1);
            core_dist(j,i)=core_dist(i,j);

        else
            count=count+1;
            core_dist(i,j)=core_dist(i,j)/(averho*numinset1);
            core_dist(j,i)=core_dist(i,j);
        end
        
    end
end

%��ֲ����ĵ�֮�����С������
SD=sparse(core_dist);
UG=tril(SD);
[ST,pred] = graphminspantree(UG,'METHOD','Prim');
ST2=full(ST);
ST2=ST2+ST2';
ST=sparse(ST2);
short_path=zeros(cluster_number,cluster_number);
for i=1:cluster_number
    short_path(i,i)=0;
    [D, ~, ~]=graphshortestpath(ST,i);
    for j=i+1:cluster_number
        short_path(i,j)=D(j);
        short_path(j,i)=short_path(i,j);
    end
end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('cluster NDPs with the improved kmeans......\n');
%Kmeans�㷨ʵ��
core_rho=rho(cores2);
[core_cl] = KmeansWithGD(A(cores2,:),'random',num_clusters,short_path,core_rho);
cl2=zeros(N,1);
cl2(cores2)=core_cl;
for i=1:N
    cl2(i)=cl2(local_core(i));
end
toc;
fprintf('Program complete��\n');
figure;
drawcluster_ndpkmeans(A,cl2,num_clusters);
end

function flag=iscontain( q,x )
%�����q��������
[m,n]=size(q);
flag=0;
for i=1:m
    if q(i)==x
        flag=1;
        break;
    end
end

end




