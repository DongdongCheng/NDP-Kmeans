% -------------------------------------------------------------------------
%Aim:
%draw the cluster results of ndpkmeans
% -------------------------------------------------------------------------
% Written by Dongdong Cheng
% December 2016
function  drawcluster_ndpkmeans(A,cluster,ncluster)
[n,d]=size(A);
cmap=colormap;
for i=1:n
    if cluster(i)>0
    ic=int8(((cluster(i))*64.)/(ncluster*1.));
    x=A(i,1);
    y=A(i,2);
%     z=A(i,3);
    plot(x,y,'o','MarkerSize',5,'MarkerFaceColor',cmap(ic,:),'MarkerEdgeColor',cmap(ic,:));
    hold on;
    else
        x=A(i,1);
        y=A(i,2);
%         z=A(i,3);
        plot(x,y,'k.');%,'MarkerSize',10);
        hold on;
    end
end
end



